import Link from "next/link";
import Image from "next/image";

import { LoginForm } from "@/components/login-form";
import bgImage from '../../../../public/images/bg.jpg';

export default function LoginPage() {
  return (
    <div className="grid min-h-svh lg:grid-cols-2">
      {/* Left Column: Form Section */}
      <div className="flex flex-col items-center justify-center p-6 md:p-10">
        {/* Logo */}
        <div className="mb-8 flex justify-center">
          <Link href="/" className="flex items-center gap-2 font-medium">
            <img
              src="/images/logo.png"
              alt="Logo"
              className="w-32 h-auto" // Adjust size as needed
            />
          </Link>
        </div>

        {/* Login Form */}
        <div className="w-full max-w-xs">
          <LoginForm />
        </div>
      </div>

      {/* Right Column: Background Image */}
      <Image
        src={bgImage}
        alt="Background"
        className="hidden lg:block object-cover w-full h-full"
      />
    </div>
  );
}