// app/(student)/lecture/[id]/page.tsx
"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter, useParams } from "next/navigation";
import { ChevronLeft, ChevronRight, Maximize, Minimize, Edit, Book, Check, CheckCircle, Video, File, MessageSquare, X, Menu, MoreVertical } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Progress } from "@/components/ui/progress";
import { getLectureById, markLectureAsCompleted, updateStudentProgress } from "./api";
import apiClient from "@/lib/api-client";
import { LectureNavigator } from "../components/lecture-navigator";
import { LectureNotes } from "../components/lecture-notes"; 
import { LectureTranscript } from "../components/lecture-transcript";

interface Lecture {
  _id: string;
  title: string;
  description: string;
  chapterId: string;
  order: number;
  estimatedDuration: number;
  prerequisites: string[];
  content: {
    type: string;
    data: {
      videoUrl?: string;
      documentUrl?: string;
      htmlContent?: string;
      duration?: number;
      transcript?: string;
    };
  };
  isPublished: boolean;
  tags: string[];
  learningObjectives?: string[] | string;
  additionalResources?: any[] | string;
}

interface Chapter {
  _id: string;
  name: string;
  displayName: string;
  subjectId: string;
  order: number;
  lectures: string[];
}

interface Subject {
  _id: string;
  name: string;
  displayName: string;
  classId: string;
}

export default function LectureViewPage() {
  const router = useRouter();
  const params = useParams();
  const lectureId = params?.id as string;
  const videoRef = useRef<HTMLVideoElement>(null);
  const [lectureData, setLectureData] = useState<Lecture | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [chapterData, setChapterData] = useState<Chapter | null>(null);
  const [subjectData, setSubjectData] = useState<Subject | null>(null);
  const [nextLecture, setNextLecture] = useState<string | null>(null);
  const [prevLecture, setPrevLecture] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showTranscript, setShowTranscript] = useState(false);
  const [isPanelCollapsed, setIsPanelCollapsed] = useState(false);
  const [notes, setNotes] = useState("");
  const [isMobile, setIsMobile] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [activeTab, setActiveTab] = useState("content");

  // Check if we're on mobile
  useEffect(() => {
    const checkIsMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkIsMobile();
    window.addEventListener("resize", checkIsMobile);
    
    return () => {
      window.removeEventListener("resize", checkIsMobile);
    };
  }, []);

  // Fetch lecture data
  useEffect(() => {
    const fetchLectureData = async () => {
      if (!lectureId) return;
      
      setLoading(true);
      try {
        console.log("Attempting to fetch lecture:", lectureId);
        const lecture = await getLectureById(lectureId);
        console.log("Lecture data received:", lecture);
        setLectureData(lecture);
        
        // Fetch chapter data to get next/prev lectures
        if (lecture.chapterId) {
          console.log("Fetching chapter data:", lecture.chapterId);
          try {
            const chapter = await getChapterById(lecture.chapterId);
            setChapterData(chapter);
            
            // Get next and previous lecture IDs
            if (chapter.lectures && Array.isArray(chapter.lectures)) {
              const lectureIndex = chapter.lectures.findIndex(
                (id: string | { _id: string }) => 
                  (typeof id === 'string' ? id : id._id) === lectureId
              );
              
              if (lectureIndex > 0) {
                setPrevLecture(
                  typeof chapter.lectures[lectureIndex - 1] === 'string' 
                    ? chapter.lectures[lectureIndex - 1] 
                    : chapter.lectures[lectureIndex - 1]._id
                );
              }
              
              if (lectureIndex < chapter.lectures.length - 1) {
                setNextLecture(
                  typeof chapter.lectures[lectureIndex + 1] === 'string' 
                    ? chapter.lectures[lectureIndex + 1] 
                    : chapter.lectures[lectureIndex + 1]._id
                );
              }
            }
            
            // Fetch subject data
            if (chapter.subjectId) {
              try {
                // Handle if subjectId is an object or string
                const subjectId = typeof chapter.subjectId === 'object' 
                  ? chapter.subjectId._id 
                  : chapter.subjectId;
                
                const subject = await getSubjectById(subjectId);
                setSubjectData(subject);
              } catch (subjectErr) {
                console.error("Error fetching subject:", subjectErr);
                // Continue execution even if subject fetch fails
              }
            }
          } catch (chapterErr) {
            console.error("Error fetching chapter:", chapterErr);
            // Continue execution even if chapter fetch fails
          }
        }
        
        // Fetch progress to check if lecture is completed
        try {
          const progressData = await getStudentProgressForLecture(lectureId);
          if (progressData) {
            setIsCompleted(progressData.isCompleted);
            setProgress(progressData.progress || 0);
            // If there are saved notes, load them
            if (progressData.notes) {
              setNotes(progressData.notes);
            }
          }
        } catch (progressErr) {
          console.error("Error fetching progress:", progressErr);
          // Continue execution even if progress fetch fails
        }
        
      } catch (err: any) {
        console.error("Error fetching lecture:", err);
        setError(err.message || "Failed to load lecture");
        toast.error("Failed to load lecture");
      } finally {
        setLoading(false);
      }
    };
    
    fetchLectureData();
  }, [lectureId]);

  // Handle video events for progress tracking
  const handleTimeUpdate = () => {
    if (videoRef.current && lectureData?.content.type === "video") {
      const duration = videoRef.current.duration;
      const currentTime = videoRef.current.currentTime;
      const percentWatched = Math.floor((currentTime / duration) * 100);
      
      // Only update if progress is higher than stored
      if (percentWatched > progress) {
        setProgress(percentWatched);
        
        // If watched more than 90%, consider it completed
        if (percentWatched > 90 && !isCompleted) {
          handleMarkAsCompleted();
        }
        
        // Update progress in database periodically (throttle)
        if (percentWatched % 10 === 0) {
          updateStudentProgress(lectureId, percentWatched, notes);
        }
      }
    }
  };

  // Handle fullscreen toggle
  const toggleFullscreen = () => {
    if (!videoRef.current) return;
    
    if (!document.fullscreenElement) {
      videoRef.current.requestFullscreen().catch(err => {
        toast.error(`Error attempting to enable fullscreen: ${err.message}`);
      });
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  // Handle video play/pause
  const togglePlayPause = () => {
    if (!videoRef.current) return;
    
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  // Handle navigation to next/prev lecture
  const navigateToLecture = (id: string | null) => {
    if (!id) return;
    router.push(`/lecture/${id}`);
  };

  // Handle mark as completed
  const handleMarkAsCompleted = async () => {
    if (isCompleted) return;
    
    try {
      await markLectureAsCompleted(lectureId);
      setIsCompleted(true);
      toast.success("Lecture marked as completed!");
      
      // Also save notes
      await updateStudentProgress(lectureId, 100, notes);
    } catch (err: any) {
      console.error("Error marking lecture as completed:", err);
      toast.error(err.message || "Failed to mark lecture as completed");
    }
  };

  // Handle saving notes
  const handleSaveNotes = async () => {
    try {
      await updateStudentProgress(lectureId, progress, notes);
      toast.success("Notes saved successfully!");
    } catch (err: any) {
      console.error("Error saving notes:", err);
      toast.error(err.message || "Failed to save notes");
    }
  };

  // Render content based on type
  const renderContent = () => {
    if (!lectureData) return null;
    
    switch (lectureData.content.type) {
      case "video":
        return (
          <div className="relative w-full aspect-video bg-black">
            <video
              ref={videoRef}
              src={lectureData.content.data.videoUrl}
              className="w-full h-full"
              controls
              onTimeUpdate={handleTimeUpdate}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
            />
            <div className="absolute bottom-0 right-0 p-2 flex space-x-2">
              <Button 
                variant="ghost" 
                size="sm" 
                className="bg-black/50 text-white hover:bg-black/70"
                onClick={toggleFullscreen}
              >
                {isFullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        );
      
      case "document":
        return (
          <div className="w-full h-[70vh] border rounded-md">
            <iframe 
              src={`${lectureData.content.data.documentUrl}#toolbar=0`} 
              className="w-full h-full"
              title={lectureData.title}
            />
          </div>
        );
        
      case "html":
        return (
          <div 
            className="w-full prose prose-lg dark:prose-invert max-w-none p-4"
            dangerouslySetInnerHTML={{ __html: lectureData.content.data.htmlContent || "" }}
          />
        );
        
      default:
        return (
          <div className="p-4 border rounded-md bg-muted">
            <p>This content type is not supported.</p>
          </div>
        );
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col min-h-screen">
        <header className="border-b py-4 px-4 bg-background">
          <div className="container mx-auto">
            <Skeleton className="h-8 w-2/3" />
          </div>
        </header>
        <main className="flex-1">
          <div className="container mx-auto py-8 space-y-4">
            <Skeleton className="h-4 w-1/2" />
            <Skeleton className="h-[50vh] w-full" />
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="md:col-span-3">
                <Skeleton className="h-20 w-full" />
              </div>
              <div className="md:col-span-1">
                <Skeleton className="h-20 w-full" />
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (error || !lectureData) {
    return (
      <div className="flex flex-col min-h-screen">
        <header className="border-b py-4 px-4 bg-background">
          <div className="container mx-auto">
            <h1 className="text-xl font-bold">Error</h1>
          </div>
        </header>
        <main className="flex-1">
          <div className="container mx-auto py-8">
            <div className="p-4 border rounded-md bg-destructive/10 text-destructive">
              <p>Failed to load lecture content. Please try again later.</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => router.push("/dashboard")}
              >
                Return to Dashboard
              </Button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b py-4 px-4 bg-background">
        <div className="container mx-auto">
          <h1 className="text-xl font-bold">{lectureData.title}</h1>
        </div>
      </header>
      <main className="flex-1">
        <div className="container mx-auto py-4">
          {/* Mobile Navigation */}
          {isMobile && (
            <div className="md:hidden flex justify-between items-center mb-4">
              <Drawer>
                <DrawerTrigger asChild>
                  <Button variant="outline" size="icon">
                    <Menu className="h-4 w-4" />
                  </Button>
                </DrawerTrigger>
                <DrawerContent>
                  <DrawerHeader>
                    <DrawerTitle>Lecture Navigation</DrawerTitle>
                  </DrawerHeader>
                  <div className="p-4 space-y-2">
                    <div className="text-sm text-muted-foreground">
                      {subjectData?.displayName} &gt; {chapterData?.displayName}
                    </div>
                    <div className="font-semibold">{lectureData.title}</div>
                    <div className="flex gap-2 mt-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => navigateToLecture(prevLecture)}
                        disabled={!prevLecture}
                      >
                        <ChevronLeft className="h-4 w-4 mr-2" /> Previous
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => navigateToLecture(nextLecture)}
                        disabled={!nextLecture}
                      >
                        Next <ChevronRight className="h-4 w-4 ml-2" />
                      </Button>
                    </div>
                    <TabsList className="grid grid-cols-3 w-full mt-4">
                      <TabsTrigger value="content" onClick={() => setActiveTab("content")}>
                        <Video className="h-4 w-4 mr-2" /> Content
                      </TabsTrigger>
                      <TabsTrigger value="transcript" onClick={() => setActiveTab("transcript")}>
                        <MessageSquare className="h-4 w-4 mr-2" /> Transcript
                      </TabsTrigger>
                      <TabsTrigger value="notes" onClick={() => setActiveTab("notes")}>
                        <Edit className="h-4 w-4 mr-2" /> Notes
                      </TabsTrigger>
                    </TabsList>
                  </div>
                </DrawerContent>
              </Drawer>
              <Button 
                variant={isCompleted ? "default" : "outline"}
                size="sm"
                onClick={handleMarkAsCompleted}
                disabled={isCompleted}
                className={isCompleted ? "bg-green-600" : ""}
              >
                {isCompleted ? 
                  <><CheckCircle className="h-4 w-4 mr-2" /> Completed</> : 
                  <><Check className="h-4 w-4 mr-2" /> Mark Complete</>
                }
              </Button>
            </div>
          )}

          {/* Desktop Header */}
          <div className="hidden md:flex justify-between items-center mb-6">
            <div className="space-y-1">
              <div className="text-sm text-muted-foreground">
                {subjectData?.displayName} &gt; {chapterData?.displayName}
              </div>
              <h1 className="text-2xl font-bold">{lectureData.title}</h1>
              <div className="flex items-center gap-4 text-sm">
                <div className="flex items-center">
                  <File className="h-4 w-4 mr-1" />
                  {lectureData.content.type.charAt(0).toUpperCase() + lectureData.content.type.slice(1)}
                </div>
                <div>
                  <span className="font-medium">{lectureData.estimatedDuration}</span> min
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                onClick={() => navigateToLecture(prevLecture)}
                disabled={!prevLecture}
              >
                <ChevronLeft className="h-4 w-4 mr-2" /> Previous
              </Button>
              <Button
                variant="outline"
                onClick={() => navigateToLecture(nextLecture)}
                disabled={!nextLecture}
              >
                Next <ChevronRight className="h-4 w-4 ml-2" />
              </Button>
              <Button 
                variant={isCompleted ? "default" : "outline"}
                onClick={handleMarkAsCompleted}
                disabled={isCompleted}
                className={isCompleted ? "bg-green-600" : ""}
              >
                {isCompleted ? 
                  <><CheckCircle className="h-4 w-4 mr-2" /> Completed</> : 
                  <><Check className="h-4 w-4 mr-2" /> Mark Complete</>
                }
              </Button>
            </div>
          </div>

          {/* Progress Indicator */}
          <div className="mb-4">
            <div className="flex justify-between text-sm mb-1">
              <span>Progress</span>
              <span>{progress}%</span>
            </div>
            <Progress value={progress} />
          </div>

          {/* Main Content */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Navigation Panel (Desktop only) */}
            {!isMobile && (
              <div className="md:col-span-1 order-2 md:order-1">
                <LectureNavigator 
                  chapterId={lectureData.chapterId} 
                  currentLectureId={lectureId}
                />
              </div>
            )}
            
            {/* Content Area */}
            <div className={isMobile ? "col-span-1 order-1" : "col-span-3 order-2"}>
              {isMobile ? (
                <Tabs value={activeTab}>
                  <TabsContent value="content" className="m-0">
                    {renderContent()}
                  </TabsContent>
                  <TabsContent value="transcript" className="m-0">
                    <div className="h-[50vh]">
                      {lectureData.content.data.transcript ? (
                        <LectureTranscript 
                          transcript={lectureData.content.data.transcript}
                          videoRef={videoRef}
                          onClose={() => setActiveTab("content")}
                        />
                      ) : (
                        <div className="flex items-center justify-center h-full border rounded-md bg-muted/20 p-4 text-muted-foreground">
                          No transcript available for this lecture.
                        </div>
                      )}
                    </div>
                  </TabsContent>
                  <TabsContent value="notes" className="m-0">
                    <LectureNotes 
                      lectureId={lectureId}
                      initialNotes={notes}
                    />
                  </TabsContent>
                </Tabs>
              ) : (
                <>
                  {renderContent()}
                  
                  {/* Transcript (Desktop) */}
                  {showTranscript && lectureData.content.data.transcript && (
                    <div className="mt-4 h-[300px]">
                      <LectureTranscript 
                        transcript={lectureData.content.data.transcript}
                        videoRef={videoRef}
                        onClose={() => setShowTranscript(false)}
                      />
                    </div>
                  )}
                  
                  {/* Description */}
                  <div className="mt-4">
                    <h3 className="text-lg font-medium mb-2">Description</h3>
                    <p className="text-muted-foreground">{lectureData.description}</p>
                  </div>

                  {/* Additional Controls */}
                  <div className="mt-4 flex flex-wrap gap-2">
                    {!showTranscript && lectureData.content.data.transcript && (
                      <Button 
                        variant="outline" 
                        onClick={() => setShowTranscript(true)}
                      >
                        <MessageSquare className="h-4 w-4 mr-2" /> Show Transcript
                      </Button>
                    )}
                  </div>
                </>
              )}
            </div>

            {/* Right Sidebar (Desktop only) */}
            {!isMobile && (
              <div className="col-span-1 order-3">
                <LectureNotes 
                  lectureId={lectureId}
                  initialNotes={notes}
                />
                
                {/* Tags */}
                {lectureData.tags && lectureData.tags.length > 0 && (
                  <div className="mt-4 border rounded-md p-4">
                    <h3 className="text-sm font-medium mb-2">Tags</h3>
                    <div className="flex flex-wrap gap-2">
                      {lectureData.tags.map((tag, index) => (
                        <div key={index} className="bg-secondary text-secondary-foreground px-2 py-1 rounded-md text-sm">
                          {tag}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Learning Objectives */}
                {lectureData.learningObjectives && (
                  <div className="mt-4 border rounded-md p-4">
                    <h3 className="text-sm font-medium mb-2">Learning Objectives</h3>
                    <ul className="space-y-1 text-sm">
                      {Array.isArray(lectureData.learningObjectives) ? (
                        lectureData.learningObjectives.map((objective, index) => (
                          <li key={index} className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>{objective}</span>
                          </li>
                        ))
                      ) : (
                        <li className="flex items-start">
                          <span className="mr-2">•</span>
                          <span>{lectureData.learningObjectives}</span>
                        </li>
                      )}
                    </ul>
                  </div>
                )}
                
                {/* Additional Resources */}
                {lectureData.additionalResources && (
                  <div className="mt-4 border rounded-md p-4">
                    <h3 className="text-sm font-medium mb-2">Additional Resources</h3>
                    <ul className="space-y-1 text-sm">
                      {Array.isArray(lectureData.additionalResources) ? (
                        lectureData.additionalResources.map((resource, index) => (
                          <li key={index} className="flex items-start">
                            <a 
                              href={resource.url || '#'} 
                              target="_blank"
                              rel="noopener noreferrer" 
                              className="text-primary hover:underline flex items-center"
                            >
                              <File className="h-3 w-3 mr-2" />
                              <span>{resource.title || resource}</span>
                            </a>
                          </li>
                        ))
                      ) : (
                        <li className="text-muted-foreground">No additional resources available</li>
                      )}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}