// import BgImg from "./bg.jpg";
import ZovoSymbol from "./zovo_symbol.svg";

export { ZovoSymbol };
