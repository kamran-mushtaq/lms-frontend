import { ui } from "./registry-components"

export const registryComponents = [
    ...ui
]